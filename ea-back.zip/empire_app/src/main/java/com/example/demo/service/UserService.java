package com.example.demo.service;

import java.util.List;

import com.example.demo.model.User;

public interface UserService {
	User findById(Integer id);
	
	void save(User user); 
	
	void update(User user); 
	
	void delete(User user);
	
	List<User> findAll(); 
	
	void deleteAll(); 
	
	boolean exist(User user); 
	
	
	

}

package com.example.demo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import com.example.demo.lib.RestPreconditions;
import com.example.demo.model.Widget;
import com.example.demo.service.WidgetService;

import jersey.repackaged.com.google.common.base.Preconditions;

@RestController
@RequestMapping("api/widgets")
public class WidgetController {

	@Autowired
	private WidgetService service;

	@RequestMapping(method = RequestMethod.GET)
	public List<Widget> findAll() {
		return service.findAll();
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Widget findOne(@PathVariable("id") Integer id) {
		return RestPreconditions.checkFound(service.findById(id));
	}

	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void create(@RequestBody Widget[] widgets) {
		System.out.println("--------------");
		
		for (Widget widget : widgets) {
			Preconditions.checkNotNull(widget);
			service.save(widget);
		}

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	public void update(@PathVariable("id") Integer id, @RequestBody Widget resource) {
		Preconditions.checkNotNull(resource);
		RestPreconditions.checkFound(service.findById(id));
		service.update(resource);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public void delete(@PathVariable("id") Integer id , @RequestBody Widget resource) {
		service.delete(resource);
	}
}

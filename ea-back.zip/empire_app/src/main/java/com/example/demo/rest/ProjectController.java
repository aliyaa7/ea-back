package com.example.demo.rest;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.lib.RestPreconditions;
import com.example.demo.model.Message;
import com.example.demo.model.Project;
import com.example.demo.model.Widget;
import com.example.demo.service.ProjectService;

import jersey.repackaged.com.google.common.base.Preconditions;

@RestController
@RequestMapping("api/Project")
public class ProjectController {
	
	private ProjectService service; 
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Project> findAll(){
		return service.findAll();
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Project findOne(@PathVariable("id") Integer id) {
		return RestPreconditions.checkFound(service.findById(id));
	}

	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void create(@RequestBody Project resource) {
		Preconditions.checkNotNull(resource);
		service.save(resource);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	public void update(@PathVariable("id") Integer id, @RequestBody Project resource) {
		Preconditions.checkNotNull(resource);
		RestPreconditions.checkFound(service.findById(id));
		service.update(resource);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public void delete(@PathVariable("id") Integer id , @RequestBody Project resource) {
		service.delete(resource);
	}
}



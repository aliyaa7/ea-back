package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Role;
import com.example.demo.model.Widget;

public interface RoleService  {

	Role findById(Integer id);

	void save(Role role);

	void update(Role role);

	void delete(Role role);

	List<Role> findAll();

	void deleteAll();

	boolean exist(Role role);
}

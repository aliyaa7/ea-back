package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Message;
import com.example.demo.model.Widget;

public interface MessageService {

	Message findById(Integer id);

	void save(Message message);

	void update(Message message);

	void delete(Message message);

	List<Message> findAll();

	void deleteAll();

	boolean exist(Message message);
}



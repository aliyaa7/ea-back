package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dao.ProjectDao;
import com.example.demo.model.Project;

@Service
public class ProjectServiceImpl implements ProjectService{

	ProjectDao dao ;

	@Override
	public Project findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Project project) {
		dao.save(project);
	}

	@Override
	public void update(Project project) {
		dao.save(project);
		
	}

	@Override
	public void delete(Project project) {
		dao.delete(project);
	}

	@Override
	public List<Project> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
	}

	@Override
	public boolean exist(Project project) {
		// TODO Auto-generated method stub
		return false;
	} 
	
}

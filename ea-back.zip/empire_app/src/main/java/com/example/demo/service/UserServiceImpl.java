package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDao;
import com.example.demo.model.User;

@Service
public class UserServiceImpl implements UserService {

	
	UserDao dao;
	
	public UserServiceImpl() {
		
	}
	
	@Override
	public User findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(User user) {
		dao.save(user);
	}

	@Override
	public void update(User user) {
		dao.save(user);
		
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
			dao.delete(user);
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		dao.deleteAll();
	}

	@Override
	public boolean exist(User user) {
		// TODO Auto-generated method stub
		return false;
	}
	

}

package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dao.GroupeDao;
import com.example.demo.model.Groupe;


@Service
public class GroupeServiceImpl implements GroupeService{

	GroupeDao dao;
	
	@Override
	public Groupe findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Groupe groupe) {
		dao.save(groupe);
		
	}

	@Override
	public void update(Groupe groupe) {
		dao.save(groupe);
	}

	@Override
	public void delete(Groupe groupe) {
		dao.delete(groupe);
		
	}

	@Override
	public List<Groupe> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
	}

	@Override
	public boolean exist(Groupe groupe) {
		// TODO Auto-generated method stub
		return false;
	}

}

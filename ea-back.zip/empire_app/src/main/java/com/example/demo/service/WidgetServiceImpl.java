package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.WidgetDao;
import com.example.demo.model.Widget;

@Service
public class WidgetServiceImpl implements WidgetService {
	
	@Autowired
	WidgetDao dao;

	public WidgetServiceImpl() {
		
	}

	@Override
	public void save(Widget widget) {
		dao.save(widget);
	}

	@Override
	public void update(Widget widget) {
		dao.save(widget);
	}

	@Override
	public void delete(Widget widget) {
		dao.delete(widget);
	}

	@Override
	public List<Widget> findAll() {
		return dao.findAll();
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
	}


	@Override
	public Widget findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean exist(Widget widget) {
		// TODO Auto-generated method stub
		return false;
	}

	

}

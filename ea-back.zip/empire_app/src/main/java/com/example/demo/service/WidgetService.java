package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Widget;



public interface WidgetService {
	
	Widget findById(Integer id);

	void save(Widget widget);

	void update(Widget widget);

	void delete(Widget widget);

	List<Widget> findAll();

	void deleteAll();

	boolean exist(Widget widget);
}

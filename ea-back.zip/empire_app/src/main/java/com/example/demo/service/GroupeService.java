package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Groupe;
import com.example.demo.model.Message;

public interface GroupeService {

	Groupe findById(Integer id);

	void save(Groupe groupe);

	void update(Groupe groupe);

	void delete(Groupe groupe);

	List<Groupe> findAll();

	void deleteAll();

	boolean exist(Groupe groupe);
}


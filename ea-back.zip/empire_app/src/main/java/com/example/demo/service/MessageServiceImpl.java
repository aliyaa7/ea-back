package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dao.MessageDao;
import com.example.demo.model.Message;

@Service
public class MessageServiceImpl implements MessageService{

	MessageDao dao;
	
	public  MessageServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Message findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Message message) {
		dao.save(message);
		
	}

	@Override
	public void update(Message message) {
		dao.save(message);
	}

	@Override
	public void delete(Message message) {
		dao.delete(message);
	}

	@Override
	public List<Message> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
	}

	@Override
	public boolean exist(Message message) {
		// TODO Auto-generated method stub
		return false;
	}
	

}

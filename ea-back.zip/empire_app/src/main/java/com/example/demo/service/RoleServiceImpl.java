package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.RoleDao;
import com.example.demo.dao.WidgetDao;
import com.example.demo.model.Role;
import com.example.demo.model.Widget;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	RoleDao dao;

	 public RoleServiceImpl() {
		// TODO Auto-generated constructor stub
	
	}	
	

	@Override
	public void save(Role role) {
		dao.save(role);
	}

	@Override
	public void update(Role role) {
		dao.save(role);
	}

	@Override
	public void delete(Role role) {
		dao.delete(role);
	}

	@Override
	public List<Role> findAll() {
		return dao.findAll();
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
	}


	@Override
	public Role findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean exist(Role role) {
		// TODO Auto-generated method stub
		return false;
	}



	

}

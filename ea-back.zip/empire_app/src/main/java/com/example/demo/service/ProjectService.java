package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Project;
import com.example.demo.model.Widget;

public interface ProjectService {
	
	Project findById(Integer id);

	void save(Project project);

	void update(Project project);

	void delete(Project project);

	List<Project> findAll();

	void deleteAll();

	boolean exist(Project project);

}

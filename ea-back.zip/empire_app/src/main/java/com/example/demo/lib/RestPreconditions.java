package com.example.demo.lib;

import javax.management.RuntimeErrorException;

public class RestPreconditions {
    public static <T> T checkFound(T resource) {
        if (resource == null) {
            throw new RuntimeErrorException(null, "Not found");
        }
        return resource;
    }
}